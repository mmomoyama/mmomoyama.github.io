﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CopyrightFileNameFixTool
{
  public partial class CopyrightFileNameFixTool : Form
  {
    public CopyrightFileNameFixTool()
    {
      InitializeComponent();
    }

    private void button1_Click(object sender, EventArgs e)
    {
      FolderBrowserDialog fbDialog = new FolderBrowserDialog();

      // ダイアログの説明文を指定する
      fbDialog.Description = "ダイアログの説明文";
      if (textBox1.Text != "" && Directory.Exists(textBox1.Text))
      {
        fbDialog.SelectedPath = textBox1.Text;
      }
      else
      {
        // デフォルトのフォルダを指定する
        fbDialog.SelectedPath = @"C:";
      }

      // 「新しいフォルダーの作成する」ボタンを表示する
      fbDialog.ShowNewFolderButton = true;

      //フォルダを選択するダイアログを表示する
      if (fbDialog.ShowDialog() == DialogResult.OK)
      {
        textBox1.Text = fbDialog.SelectedPath;
      }

      // オブジェクトを破棄する
      fbDialog.Dispose();
    }

    private void button2_Click(object sender, EventArgs e)
    {
      if(textBox1.Text == "" || !Directory.Exists(textBox1.Text))
      {
        MessageBox.Show("ディレクトリを正しく指定してください");
        return;
      }
      var fileNames = new List<string>();
      string[] extensions = {"sql", "cs"};
      FolderInsiteSearch(textBox1.Text, fileNames, extensions);
      foreach (var filename in fileNames)
      {
        string name = Path.GetFileName(filename);
        StreamReader sr = new StreamReader(filename, Encoding.GetEncoding("utf-8"));
        string str = sr.ReadToEnd();
        sr.Close();
        string str2 = System.Text.RegularExpressions.Regex.Replace(
          str, "(--<copyright.*file=\")[^ ]+(\" .+\\n)", "$1"+ name + "$2");

        if (str != str2)
        {
          // 文字コードを指定
          Encoding enc = Encoding.GetEncoding("utf-8");

          // ファイルを開く
          StreamWriter writer = new StreamWriter(filename, false, enc);

          // テキストを書き込む
          writer.WriteLine(str2);

          // ファイルを閉じる
          writer.Close();

          textBox2.Text += filename + " OK" + Environment.NewLine;
        }
        else
        {
          textBox2.Text += filename + " NO MATCH" + Environment.NewLine;
        }
        Application.DoEvents();
      }
    }
    void FolderInsiteSearch(string folderPath, List<string> list, string[] extensions)
    {
      //現在のフォルダ内の指定拡張子のファイル名をリストに追加
      foreach (var fileNames in Directory.EnumerateFiles(folderPath))
        foreach (var endId in extensions)
          if (fileNames.EndsWith(endId))
            list.Add(fileNames);
      //現在のフォルダ内のすべてのフォルダパスを取得
      var dirNames = Directory.EnumerateDirectories(folderPath);
      //フォルダがないならば再帰探索終了し、あるなら各フォルダに対して探索実行
      if (dirNames.Count() == 0)
        return;
      else
        foreach (var dirName in dirNames)
          FolderInsiteSearch(dirName, list, extensions);
    }
  }
}
